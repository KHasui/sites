% Optimal monetary policy, Commitment
% 
% NK model
%
%  period loss: 1/2*(pi^2 + x^2)
%
%  strucutural equations:
%  x = Ex - sig*(i - Epi -rn)
%  p = beta*Ep + kpp*x + u
%  rn = rhor*rn(-1) + epsrn
%  u  = rhou*rn(-1) + epsu
% 
%  FOC
%   p = phip - phip(-1)
%   x = -kappa/lambdax*phip

close
clear

% Parameters
betta   = .99;   % discount factor
sig     = 6.25;  % intertemporal elastisity
kappa   = 0.024; % slope of NKPC
tht     = 7.88;  % elasticity of lavor
lambdax = kappa/tht; % weight on output gap
rhor    = .5;    % persistence of natural rate
rhou    = 0;   % persistence of cost shock

% System of the model:
% A*X(t) = B*X(t-1) + C*eps(t) + D*eta(t)
% X = [pi, x, i, phip, Ex, Epi, rn, u]'
% eps(t) = [epsr epsu]': natural rate shock, cost-push shock
% eta(t) = [eta_c eta_y]': Expectation error

% Prepare matrices

N = 8; neps = 2; neta = 2; % # of variables, shocks, and expectation errors.

A = zeros(N,N);
B = zeros(N,N);
C = zeros(N,neps);
D = zeros(N,neta);

% 1. NKPC
A(1,1) = 1;
A(1,2) = -kappa;
A(1,6) = -betta;
A(1,8) = -1;

% 2. DIS
A(2,2) = 1;
A(2,3) = sig;
A(2,5) = -1;
A(2,6) = -sig;
A(2,7) = -sig;

% 3. Foc for inflation
A(3,1) = 1;
A(3,4) = -1;
B(3,4) = -1;

% 4. Foc for output gap
A(4,2) = 1;
A(4,4) = kappa/lambdax;

% 5. AR1 for rn
A(5,7) = 1;
B(5,7) = rhor;
C(5,1) = 1;

% 6. AR1 for u
A(6,8) = 1;
B(6,8) = rhou;
C(6,2) = 1;

% 7. Expectation error of inflation
A(7,1) = 1;
B(7,6) = 1;
D(7,2) = 1;

% 8. Expectation error of inflation
A(8,2) = 1;
B(8,5) = 1;
D(8,1) = 1;

% 
% Eigen value decomposition
% 
% Apply generalized schur(QZ) decomposition for A and B.
%
%  A*X(t) = B*X(t-1) + C*eps(t) + D*eta(t)
%  A = Q'SZ', B = Q'TZ'
%
%  where QQ' = ZZ' = I(N by N).
%
[S,T,Q,Z] = qz(A,B);
s = diag(S);
t = diag(T);
lambda = abs(t./s) < 1-eps;
% If t(ii)/s(ii) < 1, eigen value for i is stable root.  
% Then lambda is a dummy vector which return 1 if eigen value is stable. 

% reorder by recalling ordqz
[S,T,Q,Z] = ordqz(S,T,Q,Z,lambda);
s = diag(S);
t = diag(T);
lambda = abs(t./s) < 1-eps;
NS = sum(lambda);
%
% NS is the number of state variable.
%

% Blanchard and Kahn condition
if NS == N-neta
    disp(' Checking Blanchard and Kahn condition (BKC)... ')
    disp(['  ',num2str(N-NS),' unstable roots'])
    disp(['  ',num2str(neta),' jump variables'])
    disp(['  ',num2str(NS),' stable roots'])
    disp(['  ',num2str(N-neta),' state variables'])
    disp(' BKC is satisfied.')
    disp(' ')
else
    disp(' Checking Blanchard and Kahn condition (BKC)...')
    disp(['  ',num2str(N-NS),' unstable roots'])
    disp(['  ',num2str(neta),' jump variables'])
    disp(['  ',num2str(NS),' stable roots'])
    disp(['  ',num2str(N-neta),' state variables'])
    error('BKC is not satisfied')
end

% Divide stable and unstable block
%
% Q'*S*Z'*X(t) = Q'*T*Z'*X(t-1)+C*eps(t)+D*eta(t)
%
% where S and T are upper triangular
%
S11 = S(1:NS,1:NS);
S12 = S(1:NS,NS+1:N);
S22 = S(NS+1:N,NS+1:N);
T11 = T(1:NS,1:NS);
T12 = T(1:NS,NS+1:N);
T22 = T(NS+1:N,NS+1:N);
%
% Solution form is
%
%  s(t) = Mx*s(t-1)+Me*eps(t),
%
% where
%
%  M = Z*(S11\T11 S11\(T12-Phi*Tss);0 0)*Z'
%  Me = Z*(S11\(Q1-Phi*Q2);0)*C
%  Phi = Q1*D*((Q2*D)\eye(size(Q2*D,2)));
%
Q1 = Q(1:NS,:);   % stable block of Q
Q2 = Q(NS+1:N,:); % unstable block of Q
Phi = Q1*D*((Q2*D)\eye(size(Q2*D,2))); % definition of Phi
GG = zeros(N,N);
GG11 = S11\T11;
GG12 = S11\(T12-Phi*T22);
GG(1:NS,1:NS) = GG11;    % insert GG11 into stable block of GG
GG(1:NS,NS+1:N) = GG12;  % insert GG12 into unstable block of GG
% Mx
Mx = Z*GG*(Z\eye(size(Z,2)));
GZ = zeros(N,N);
GZ(1:NS,:) = S11\(Q1-Phi*Q2);
% Me
Me = Z*GZ*C;

%
% Impulse responses
%

T = 20;    % irf period
X  = zeros(N,T); % box

varrn = 0; % natural rate shock
varu = -2; % cost-push shock

eps_t = [varrn,varu];

% for initial period
X(:,1) = Me*eps_t'; 
% following periods
for t = 2:T
    X(:,t) = Mx*X(:,t-1);
end
%Extradct and set names
p = X(1,:);
x = X(2,:);
i = X(3,:);
rn = X(7,:);
u = X(8,:);

%
% Plot impulse responses
%

lw = 1;                     % line width of impulse responses
zeroline = zeros(1,T);      % steady state lines

figure(1)

subplot(3,2,1) % output
 h = plot(1:T,p); % plot(irf period, irf, irf period, zeroline)
 set(h(1),'linewidth',lw)      % irf line width
 title('Inflation (\pi)')           % irf name
 xlabel('quarters')            % label name of x axis
 ylabel('percent deviation')   % label name of y axis
 
subplot(3,2,2) % consumption
 h = plot(1:T,x);
 set(h(1),'linewidth',lw)
 title('Output gap (x)')
 
subplot(3,2,3) % investment
 h = plot(1:T,i);
 set(h(1),'linewidth',lw)
 title('Interest rate (i)')
 
subplot(3,2,4) % labor
 h = plot(1:T,rn);
 set(h(1),'linewidth',lw)
 title('Natural rate (r^n)')

subplot(3,2,5) % technology
 h = plot(1:T,u);
 set(h(1),'linewidth',lw)
 title('Cosy-push shock (u)')

